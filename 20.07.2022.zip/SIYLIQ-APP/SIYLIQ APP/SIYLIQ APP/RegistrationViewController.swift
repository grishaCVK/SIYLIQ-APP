//
//  RegistrationViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class RegistrationViewController: UIViewController {
    
    //Variables
    
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    
    //AccountLabel Outlet

    @IBOutlet weak var accountHave: UILabel!
    
    //TextField's Outlet's
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var passwordRepeat: UITextField!
    
    //Button's Outlet's
    
    @IBOutlet weak var continueInput: UIButton!
    
    @IBOutlet weak var enter: UIButton!
    
    @IBOutlet weak var skip: UIButton!
    
    //Start Function
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Настройки TextField'a ввода логина
        email.layer.cornerRadius = 15
        email.layer.borderWidth = 1
        email.layer.borderColor = textFieldBorderColor.cgColor
        email.textColor = mainGrayColor
        email.attributedPlaceholder =
        NSAttributedString(string: "   Введите ваш email", attributes: [NSAttributedString.Key.foregroundColor: mainGrayColor])
        password.font = UIFont(name: "Archivo-Regular", size: 16)
        
            
        //Настройки TextField'a ввода пороля
        
        password.layer.cornerRadius = 15
        password.layer.borderWidth = 1
        password.layer.borderColor = textFieldBorderColor.cgColor
        password.textColor = mainGrayColor
        password.attributedPlaceholder =
        NSAttributedString(string: "   Введите ваш пароль", attributes: [NSAttributedString.Key.foregroundColor: mainGrayColor])
        password.font = UIFont(name: "Archivo-Regular", size: 16)
        
        //Настройки TextField'a повтора ввода пороля
        
        passwordRepeat.layer.cornerRadius = 15
        passwordRepeat.layer.borderWidth = 1
        passwordRepeat.layer.borderColor = textFieldBorderColor.cgColor
        passwordRepeat.textColor = mainGrayColor
        passwordRepeat.attributedPlaceholder =
        NSAttributedString(string: "   Введите ваш email", attributes: [NSAttributedString.Key.foregroundColor: mainGrayColor])
        passwordRepeat.font = UIFont(name: "Archivo-Regular", size: 16)
        
        //Настройки надписи : "Уже есть аккаунт?", ""Войти"", ""Пропустить""
        
        accountHave.backgroundColor = .white

        accountHave.textColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
        accountHave.font = UIFont(name: "Archivo-Regular", size: 14)
        
        enter.setTitleColor(mainGreenColor, for: .normal)
        enter?.titleLabel?.font = UIFont(name: "Archivo-Regular", size: 14)
        
        skip.setTitleColor(mainGreenColor, for: .normal)
        skip?.titleLabel?.font = UIFont(name: "Archivo-Regular", size: 16)
        
        //UI настройки кнопки "Продолжить"
        
        continueInput?.layer.backgroundColor = mainGreenColor.cgColor
        continueInput?.layer.cornerRadius = 15
        continueInput?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 16)
        
    }

}
