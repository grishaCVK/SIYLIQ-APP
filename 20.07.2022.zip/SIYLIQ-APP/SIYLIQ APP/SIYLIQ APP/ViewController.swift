//
//  ViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 03.05.2022.
//

import UIKit

class ViewController: UIViewController {
    
    //Variables
    
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    
    //Label's Outlet's
    
    @IBOutlet weak var firstLabel: UILabel!
    
    @IBOutlet weak var secondLabel: UILabel!
    
    @IBOutlet weak var thirdLabel: UILabel!
    
    @IBOutlet weak var fourthLabel: UILabel!
    
    //Button's Outlet's first page
    
    @IBOutlet weak var firstButton1: UIButton!
    
    @IBOutlet weak var secondButton1: UIButton!
    
    //Button's Outlet's second page
    
    @IBOutlet weak var firstButton2: UIButton!
    
    @IBOutlet weak var secondButton2: UIButton!
    
    //Button's Outlets third page
    
    @IBOutlet weak var firstButton3: UIButton!
    
    @IBOutlet weak var secondButton3: UIButton!
    
    //Button's Outlets's fourth page
    
    @IBOutlet weak var secondButton4: UIButton!
    
    //Start Function
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*firstLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        secondLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        thirdLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        fourthLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        */
        
        //Настройки кнопки "Пропустить" на первой странице
        
        firstButton1?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        //Настройки кнопки "Продолжить" на первой странице
        secondButton1?.layer.backgroundColor = mainGreenColor.cgColor
        secondButton1?.layer.cornerRadius = 15
        secondButton1?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Пропустить" на второй странице
        
        firstButton2?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Продолжить" на второй странице
        secondButton2?.layer.backgroundColor = mainGreenColor.cgColor
        secondButton2?.layer.cornerRadius = 15
        secondButton2?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Пропустить" на третьей странице
        
        firstButton3?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Продолжить" на третьей странице
        secondButton3?.layer.backgroundColor = mainGreenColor.cgColor
        secondButton3?.layer.cornerRadius = 15
        secondButton3?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Давайте начинать" на четвертой странице
        
        secondButton4?.layer.backgroundColor = mainGreenColor.cgColor
        secondButton4?.layer.cornerRadius = 15
        secondButton4?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки всех лейблов
        
        firstLabel?.font = UIFont(name : "Archivo-Bold", size: 32)
        firstLabel?.textColor = mainBlackColor
        
        secondLabel?.font = UIFont(name : "Archivo-Bold", size: 32)
        secondLabel?.textColor = mainBlackColor
        
        thirdLabel?.font = UIFont(name : "Archivo-Bold", size: 32)
        thirdLabel?.textColor = mainBlackColor
        
        fourthLabel?.font = UIFont(name : "Archivo-Bold", size: 30)
        fourthLabel?.textColor = mainBlackColor
    }

}

