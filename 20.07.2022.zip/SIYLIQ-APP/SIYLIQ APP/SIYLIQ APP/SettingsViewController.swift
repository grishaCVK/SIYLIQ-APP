//
//  SettingsViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 16.07.2022.
//

import UIKit

class SettingsViewController: UIViewController {
    
    //Variables
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let subGrayColor = UIColor(red: 0.98, green: 0.98, blue: 0.984, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    
    //Button's
    @IBOutlet weak var personName: UIButton!
    @IBOutlet weak var personEmail: UIButton!
    @IBOutlet weak var personPhoneNumber: UIButton!
    @IBOutlet weak var personLogOut: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        personName?.layer.backgroundColor = subGrayColor.cgColor
        personName?.layer.cornerRadius = 15
        personName?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        personEmail?.layer.backgroundColor = subGrayColor.cgColor
        personEmail?.layer.cornerRadius = 15
        personEmail?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        personPhoneNumber?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        personPhoneNumber?.layer.backgroundColor = subGrayColor.cgColor
        personPhoneNumber?.layer.cornerRadius = 15

        
        personLogOut?.layer.cornerRadius = 15
        personLogOut?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
