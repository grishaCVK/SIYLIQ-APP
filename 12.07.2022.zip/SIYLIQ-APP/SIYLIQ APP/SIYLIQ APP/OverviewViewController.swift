//
//  OverviewViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class OverviewViewController: UIViewController {

    //Variables
    
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    
    //Start function
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
