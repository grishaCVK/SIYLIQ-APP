//
//  ViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 03.05.2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var firstLabel: UILabel!
    
    @IBOutlet weak var secondLabel: UILabel!
    
    @IBOutlet weak var thirdLabel: UILabel!
    
    @IBOutlet weak var fourthLabel: UILabel!
    
    //
    
    @IBOutlet weak var firstButton1: UIButton!
    
    @IBOutlet weak var secondButton1: UIButton!
    
    //
    
    @IBOutlet weak var firstButton2: UIButton!
    
    @IBOutlet weak var secondButton2: UIButton!
    
    //
    
    @IBOutlet weak var firstButton3: UIButton!
    
    @IBOutlet weak var secondButton3: UIButton!
    
    //
    
    
    @IBOutlet weak var secondButton4: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*firstLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        secondLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        thirdLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        fourthLabel?.font = UIFont(name: "Archivo-Bold", size: 32)
        */
        //
        
        firstButton1?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        //
        secondButton1?.layer.backgroundColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1).cgColor
        secondButton1?.layer.cornerRadius = 15
        view.backgroundColor = .white
        secondButton1?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //
        
        firstButton2?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //
        secondButton2?.layer.backgroundColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1).cgColor
        secondButton2?.layer.cornerRadius = 15
        view.backgroundColor = .white
        secondButton2?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //
        
        firstButton3?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //
        secondButton3?.layer.backgroundColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1).cgColor
        secondButton3?.layer.cornerRadius = 15
        view.backgroundColor = .white
        secondButton3?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //
        
        secondButton4?.layer.backgroundColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1).cgColor
        secondButton4?.layer.cornerRadius = 15
        view.backgroundColor = .white
        secondButton4?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
    }

}

