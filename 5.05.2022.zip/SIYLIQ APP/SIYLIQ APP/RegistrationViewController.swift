//
//  RegistrationViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class RegistrationViewController: UIViewController {

    @IBOutlet weak var accountHave: UILabel!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var passwordRepeat: UITextField!
    
    @IBOutlet weak var continueInput: UIButton!
    
    @IBOutlet weak var enter: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Настройки закругления TextField'a ввода логина
        email.layer.cornerRadius = 15
        email.layer.borderWidth = 1
        email.layer.borderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1).cgColor
            
        //Настройки закругления TextField'a ввода пороля
        
        password.layer.cornerRadius = 15
        password.layer.borderWidth = 1
        password.layer.borderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1).cgColor
        
        //Настройки закругления TextField'a повтора ввода пороля
        
        passwordRepeat.layer.cornerRadius = 15
        passwordRepeat.layer.borderWidth = 1
        passwordRepeat.layer.borderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1).cgColor
        
        //Настройки надписи : "Уже есть аккаунт?"
        
        accountHave.frame = CGRect(x: 107, y: 451, width: 161, height: 18)
        accountHave.backgroundColor = .white

        accountHave.textColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
        accountHave.font = UIFont(name: "Zapfino", size: 13)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 1.29

        // Line height: 18 pt(К надписи "Уже есть аккаунт?")

        accountHave.attributedText = NSMutableAttributedString(string: "Уже есть аккаунт?", attributes: [NSAttributedString.Key.paragraphStyle: paragraphStyle])
        
        //UI настройки кнопки "Продолжить"
        
        continueInput?.titleLabel?.textColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
        paragraphStyle.lineHeightMultiple = 1.29

        // Line height: 22 pt


        continueInput?.layer.backgroundColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1).cgColor
        continueInput?.layer.cornerRadius = 15
        view.backgroundColor = .white
        continueInput?.titleLabel?.font = UIFont(name: "Zapfino", size: 32)
        
    }

}
