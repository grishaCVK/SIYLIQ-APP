//
//  LoginViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var emailTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTF.layer.cornerRadius = 15
        emailTF.layer.borderWidth = 1
        emailTF.layer.borderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1).cgColor

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
