//
//  ProfileViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class ProfileViewController: UIViewController {
    
    //Variables
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let subGrayColor = UIColor(red: 0.98, green: 0.98, blue: 0.984, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    
    //Label's
    
    //Button's
    @IBOutlet weak var accountSettings: UIButton!
    @IBOutlet weak var paymentMethods: UIButton!
    @IBOutlet weak var myAddresses: UIButton!
    @IBOutlet weak var appWork: UIButton!
    
    //Image View's
    @IBOutlet weak var profileImage: UIImageView!
    
    //Start function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //image round
        
        profileImage.layer.borderWidth = 1
        profileImage.layer.masksToBounds = false
        profileImage.layer.borderColor = UIColor.black.cgColor
        profileImage.layer.cornerRadius = profileImage.frame.height/2
        profileImage.clipsToBounds = true
        
        //Настройки кнопки "Настройки аккаунта"
        
        accountSettings?.layer.backgroundColor = subGrayColor.cgColor
        accountSettings?.layer.cornerRadius = 15
        accountSettings?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        
        //Настройки кнопки "Способы оплаты"
        
        paymentMethods?.layer.backgroundColor = subGrayColor.cgColor
        paymentMethods?.layer.cornerRadius = 15
        paymentMethods?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Мои адреса"
        
        myAddresses?.layer.backgroundColor = mainGreenColor.cgColor
        myAddresses?.layer.cornerRadius = 15
        myAddresses?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
        
        //Настройки кнопки "Как работает SIYLIQ APP"
        
        appWork?.layer.backgroundColor = mainGreenColor.cgColor
        appWork?.layer.cornerRadius = 15
        appWork?.titleLabel?.font = UIFont(name: "Archivo-Bold", size: 18)
    }
    

   

}
