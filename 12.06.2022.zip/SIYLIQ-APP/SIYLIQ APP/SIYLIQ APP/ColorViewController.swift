//
//  ColorViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 07.05.2022.
//

import UIKit

class ColorViewController: UIViewController {
    
    //Variables
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }


}
