//
//  LoginViewController.swift
//  SIYLIQ APP
//
//  Created by grisha on 04.05.2022.
//

import UIKit

class LoginViewController: UIViewController {
    
    //Variables
    let mainGrayColor = UIColor(red: 0.255, green: 0.259, blue: 0.286, alpha: 1)
    let textFieldBorderColor = UIColor(red: 0.854, green: 0.87, blue: 0.89, alpha: 1)
    let mainBlackColor = UIColor(red: 0.035, green: 0.063, blue: 0.114, alpha: 1)
    let mainGreenColor = UIColor(red: 0.02, green: 0.58, blue: 0.31, alpha: 1)
    
    
    //""Или"", ""Забыли пароль?"", ""Нет аккаунта?"", ""Регистрация сейчас"", ""Пропустить"" Outlet's
    @IBOutlet weak var or: UILabel!
    @IBOutlet weak var forgot: UIButton!
    @IBOutlet weak var noAccount: UILabel!
    @IBOutlet weak var registerNow: UIButton!
    @IBOutlet weak var skip: UIButton!
    
    
    //TextField's Outlet's
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var password: UITextField!
    
    //Button's Outlet's
    @IBOutlet weak var continueInput: UIButton!
    @IBOutlet weak var continueApple: UIButton!
    @IBOutlet weak var continueFacebook: UIButton!
    @IBOutlet weak var continueGoogle: UIButton!
    
    //Start function
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        //Настройкм TextFiels'a email
        
        emailTF.layer.cornerRadius = 15
        emailTF.layer.borderWidth = 1
        emailTF.layer.borderColor = textFieldBorderColor.cgColor
        emailTF.textColor = mainGrayColor
        emailTF.attributedPlaceholder =
        NSAttributedString(string: "   Введите ваш email", attributes: [NSAttributedString.Key.foregroundColor: mainGrayColor])
        emailTF.font = UIFont(name: "Archivo-Regular", size: 16)
        
        
        
        //Настройки Textfield'a password
        
        password.layer.cornerRadius = 15
        password.layer.borderWidth = 1
        password.layer.borderColor = textFieldBorderColor.cgColor
        password.textColor = mainGrayColor
        password.attributedPlaceholder =
        NSAttributedString(string: "   Введите ваш пароль", attributes: [NSAttributedString.Key.foregroundColor: mainGrayColor])
        password.font = UIFont(name: "Archivo-Regular", size: 16)
        
        
        
        //Кнопка ""или"", ""Забыли пароль?"", ""Нет аккаунта?"", ""Зарегистрируйтесь сейчас"", ""Пропустить""
        
        or.textColor = mainBlackColor
        or.font = UIFont(name: "Archivo-SemiBold", size: 14)
        forgot.setTitleColor(mainGrayColor, for: .normal)
        forgot?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 14)
        noAccount.textColor = mainBlackColor
        noAccount.font = UIFont(name: "Archivo-Regular", size: 14)
        registerNow.setTitleColor(mainGreenColor, for: .normal)
        registerNow?.titleLabel?.font = UIFont(name: "Archivo-Regular", size: 14)
        skip.setTitleColor(mainGreenColor, for: .normal)
        skip?.titleLabel?.font = UIFont(name: "Archivo-Regular", size: 16)
        
        
        
        //Настройки всех продолжить(continue)
        
        //continue
        continueInput?.layer.backgroundColor = mainGreenColor.cgColor
        continueInput?.layer.cornerRadius = 15
        continueInput?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 16)
        //Apple
        continueApple?.layer.backgroundColor = mainBlackColor.cgColor
        continueApple?.layer.cornerRadius = 15
        continueApple?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 16)
        continueApple.imageView?.layer.transform = CATransform3DMakeScale(2.5, 2.5, 2.5)
        //Facebook
        continueFacebook?.layer.backgroundColor = UIColor(red: 0.259, green: 0.404, blue: 0.698, alpha: 1).cgColor
        continueFacebook?.layer.cornerRadius = 15
        continueFacebook?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 16)
        continueFacebook.imageView?.layer.transform = CATransform3DMakeScale(2.5, 2.5, 2.5)
        //Google
        continueGoogle?.layer.backgroundColor = UIColor(red: 0.259, green: 0.522, blue: 0.957, alpha: 1).cgColor
        continueGoogle?.layer.cornerRadius = 15
        continueGoogle?.titleLabel?.font = UIFont(name: "Archivo-SemiBold", size: 16)
        continueGoogle.imageView?.layer.transform = CATransform3DMakeScale(2.5, 2.5, 2.5)
    }
    
}
